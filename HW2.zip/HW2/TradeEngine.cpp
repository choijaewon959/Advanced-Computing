//
// Created by Jae Won Choi on 6/4/2026.
//

#include "TradeEngine.h"


void TradeEngine::process() {
    for (const auto& tick : market_data) {
        // Update history
        updateHistory(tick);

        // Apply signals
        bool buy = false, sell = false;

        if (signal1(tick)) {
            buy = true;
            signal_counter[1]++;
        }
        if (signal2(tick)) {
            if (tick.price < getAvg(tick.instrument_id)) buy = true; else sell = true;
            signal_counter[2]++;
        }
        if (signal3(tick)) {
            buy = true;
            signal_counter[3]++;
        }

        if (buy || sell) {
            auto now = std::chrono::high_resolution_clock::now();
            Order o { tick.instrument_id, tick.price + (buy ? 0.01 : -0.01), buy, now };
            orders.push_back(o);

            auto latency = std::chrono::duration_cast<std::chrono::nanoseconds>(now - tick.timestamp).count();
            latencies.push_back(latency);
        }
    }
}

void TradeEngine::reportStats() {
    long long sum = 0, max_latency = 0;
    for (auto l : latencies) {
        sum += l;
        if (l > max_latency) max_latency = l;
    }

    std::cout << "\n--- Performance Report ---\n";
    std::cout << "Total Market Ticks Processed: " << market_data.size() << "\n";
    std::cout << "Total Orders Placed: " << orders.size() << "\n";
    std::cout << "Average Tick-to-Trade Latency (ns): "
              << (latencies.empty() ? 0.0 : static_cast<double>(sum) / latencies.size())
              << "\n";
    std::cout << "Maximum Tick-to-Trade Latency (ns): " << max_latency << "\n";
}

void TradeEngine::updateHistory(const MarketData& tick) {
    auto& hist = price_history[tick.instrument_id];
    hist.push_back(tick.price);
    if (hist.size() > 10) hist.erase(hist.begin());
}

double TradeEngine::getAvg(int id) {
    auto& hist = price_history[id];
    double sum = 0;
    for (double p : hist) sum += p;
    return hist.empty() ? 0 : sum / hist.size();
}

bool TradeEngine::signal1(const MarketData& tick) {
    return tick.price < 105.0 || tick.price > 195.0;
}

bool TradeEngine::signal2(const MarketData& tick) {
    if (price_history[tick.instrument_id].size() < 5) return false;
    double avg = getAvg(tick.instrument_id);
    return tick.price < avg * 0.98 || tick.price > avg * 1.02;
}

bool TradeEngine::signal3(const MarketData& tick) {
    auto& hist = price_history[tick.instrument_id];
    if (hist.size() < 3) return false;
    double diff1 = hist[hist.size() - 2] - hist[hist.size() - 3];
    double diff2 = hist[hist.size() - 1] - hist[hist.size() - 2];
    return diff1 > 0 && diff2 > 0;
}